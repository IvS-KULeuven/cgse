All you need to get started using and building the CGSE.

## Requirements

- Python 3.9.x (we do not yet support higher versions, but are working to extend the list)
- macOS or Linux

# Developer Guide

Welcome to the CGSE developer guide! An in-depth reference on how to contribute to the CGSE.


# Working with `uv`

`uv` is an extremely fast Python package and project manager, written in Rust. We will use `uv` as the single tool that replaces `pip`, `virtualenv`, `pyenv`, and more. The main tasks for which we will use `uv` are:

- run and install Python versions
- installing and managing a virtual environment
- build all the packages in the workspace or monorepo
- publish all the packages to PyPI
- run scripts and apps

## Installing `uv`

On macOS and Linux you can install `uv` using `curl`:

```shell
$ curl -LsSf https://astral.sh/uv/install.sh | sh
```

If you need more specific information on installing and upgrading `uv`, please refer to the [official documentation](https://docs.astral.sh/uv/getting-started/installation/).


## Installing a Python version

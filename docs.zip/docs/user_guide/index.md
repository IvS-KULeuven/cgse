# User Guide

Welcome to the CGSE user guide! An in-depth reference on how to with the CGSE.
